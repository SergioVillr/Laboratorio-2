package org.una.Casa_Subasta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasaSubastaApplicationTests {

	@Test
	void contextLoads() {
	}

}
